# Tiny local web server for the WebGL game. Closes when this window is closed.
$root = $PSScriptRoot
$types = @{ '.html'='text/html; charset=utf-8'; '.js'='application/javascript'; '.wasm'='application/wasm'; '.css'='text/css'; '.png'='image/png'; '.ico'='image/x-icon'; '.json'='application/json' }
$listener = $null
foreach ($p in 8790..8799) { try { $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $p); $listener.Start(); $port = $p; break } catch { $listener = $null } }
if (-not $listener) { Write-Host 'No free port 8790-8799'; Read-Host; exit 1 }
$url = "http://127.0.0.1:$port/index.html"
Write-Host "Game is running: $url"
Write-Host 'Close this window to stop.'
Start-Process $url
while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
    $stream = $client.GetStream()
    $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII, $false, 4096, $true)
    $line = $reader.ReadLine()
    while (($h = $reader.ReadLine()) -ne $null -and $h -ne '') { }
    $path = '/index.html'
    if ($line -match '^GET (\S+)') { $path = [Uri]::UnescapeDataString(($Matches[1] -split '\?')[0]) }
    if ($path -eq '/') { $path = '/index.html' }
    $file = [IO.Path]::GetFullPath((Join-Path $root $path.TrimStart('/')))
    if ($file.StartsWith($root) -and [IO.File]::Exists($file)) {
      $body = [IO.File]::ReadAllBytes($file)
      $ct = $types[[IO.Path]::GetExtension($file).ToLower()]; if (-not $ct) { $ct = 'application/octet-stream' }
      $head = "HTTP/1.1 200 OK`r`nContent-Type: $ct`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
    } else {
      $body = [Text.Encoding]::ASCII.GetBytes('Not found')
      $head = "HTTP/1.1 404 Not Found`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
    }
    $hb = [Text.Encoding]::ASCII.GetBytes($head)
    $stream.Write($hb, 0, $hb.Length); $stream.Write($body, 0, $body.Length); $stream.Flush()
  } catch { } finally { $client.Close() }
}
